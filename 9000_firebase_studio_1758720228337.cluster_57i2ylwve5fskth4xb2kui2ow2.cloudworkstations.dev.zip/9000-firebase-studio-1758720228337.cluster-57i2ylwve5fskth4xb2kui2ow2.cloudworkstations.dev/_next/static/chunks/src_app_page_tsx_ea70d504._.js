(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
        "static/chunks/src_712167ce._.js",
        "static/chunks/node_modules_framer-motion_dist_es_a4d614ec._.js",
        "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
        "static/chunks/node_modules_6be0fa48._.js"
    ],
    source: "dynamic"
});